<?php
$host = "localhost";
$user = "root";
$password = "assignment";
$db = "assignment";

$conn = mysqli_connect($host, $user, $password, $db);

if (mysqli_connect_error()) {
  die("Connection failed: " . mysqli_connect_error());
}
?>