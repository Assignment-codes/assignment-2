<?php
include('conn.php');

$id = $_GET['id'];

$sql = "DELETE FROM Books_Store WHERE ID=$id";
if (mysqli_query($conn, $sql)) {
    header("Location: index.php"); // Redirect back to the main page
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
?>