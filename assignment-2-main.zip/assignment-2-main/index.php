<DOCTYPE! html>
<html>
<head>
    <title>Book Store</title>
</head>
<body>
    <h1>Book Store</h1>
    <form method="POST" action="add.php">
        <label>Title: </label><input type="text" name="title" required><br><br>
        <label>Author: </label><input type="text" name="author" required><br><br>
        <button type="submit">Add Book</button>
    </form>

    <h2>Book List</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Action</th>
        </tr>
        <?php
        include('conn.php');
        $result = mysqli_query($conn, "SELECT * FROM Books_Store");
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['ID']}</td>
                    <td>{$row['title']}</td>
                    <td>{$row['author']}</td>
                    <td><a href='delete.php?id={$row['ID']}'>Delete</a></td>
                  </tr>";
        }
        ?>
    </table>
</body>
</html>