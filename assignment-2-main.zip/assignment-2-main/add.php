<?php
include('conn.php');

$title = $_POST['title'];
$author = $_POST['author'];

$sql = "INSERT INTO Books_Store (title, author) VALUES ('$title', '$author')";
if (mysqli_query($conn, $sql)) {
    header("Location: index.php"); 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
?>